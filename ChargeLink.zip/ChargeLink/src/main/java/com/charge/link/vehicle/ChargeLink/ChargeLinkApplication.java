package com.charge.link.vehicle.ChargeLink;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ChargeLinkApplication {

	public static void main(String[] args) {
		SpringApplication.run(ChargeLinkApplication.class, args);
	}

}
